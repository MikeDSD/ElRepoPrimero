from setuptools import setup
setup(
    name="Paquete Mike",
    version="1.0",
    description="Paquete de Prueba",
    author="Mike",

    packages=["paquete"],
)
